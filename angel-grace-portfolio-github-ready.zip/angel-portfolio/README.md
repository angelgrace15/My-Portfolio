# Angel Grace D. Galima — IT Portfolio

A responsive, dark glassmorphism portfolio for a BSIT student specializing in Web & Mobile Application Development at Nueva Vizcaya State University.

## Run locally
Open `index.html` in a browser, or use VS Code Live Server.

## Deploy to GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html`, `style.css`, `script.js`, and `assets/`.
3. Go to **Settings → Pages**.
4. Select the main branch and root folder.
5. Save and open the generated Pages URL.

## Before publishing
Replace the placeholder GitHub, Facebook, CV, project repository, and live-demo links with your real links. For the contact form, use Formspree, EmailJS, or a backend endpoint if you want web-form submissions instead of opening the email app.

## Structure
```text
angel-portfolio/
├── index.html
├── style.css
├── script.js
├── README.md
├── .gitignore
└── assets/
```
